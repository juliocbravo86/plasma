<?php
/**
 * @file
 * Default output for a galleria node.
*/
?>
<div class="galleria-content clearfix" id="galleria-<?php print $id; ?>">
  <?php print render($items); ?>
</div>
